## README / Notes

* **Shortcode**: use `[vinted_fee_calculator]` in any post/page/widget (text/html) to show the calculator.
* **Behavior**:

  * Email confirm required before inputs enable (same UX as previous plugins). Confirmed email persists to `localStorage` so it remains confirmed on refresh.
  * **Vinted Fee**: Private sellers = 0%; Pro Seller (Business) = 6.5% of Item Sale Price.
  * **VAT on Fee (20%)**: applied only for Europe & Pro Seller (per your test cases).
  * **Shipping Profit** = Shipping Charges − Shipping Cost.
  * **Total Fees** = Vinted Fee + VAT on Fee.
  * **Earnings** = Item Sale Price − Total Fees + Shipping Profit.
  * **Your Profit** = Earnings − Item Cost.
  * **Profit Margin** = (Profit / Earnings) × 100.
* **Design & theme integration**: CSS intentionally uses `font-family: inherit; color: inherit;` and CSS variables so button color/typography follow the theme/Elementor.
* You can change default rates by using the `vinted_calc_rates` filter in your theme's `functions.php`.
