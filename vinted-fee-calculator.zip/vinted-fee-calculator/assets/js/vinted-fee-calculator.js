(function(){
    function qs(sel, el) { return (el || document).querySelector(sel); }
    var rates = (window.VintedCalcData && window.VintedCalcData.rates) ? window.VintedCalcData.rates : {};

    document.addEventListener('DOMContentLoaded', function(){
        var root = qs('.vinted-calc');
        if(!root) return;

        var email = qs('#vinted-email', root);
        var confirmBtn = qs('#vinted-confirm-email', root);
        var clearBtn = qs('#vinted-clear', root);

        var inputs = [
            qs('#vinted-region', root),
            qs('#vinted-seller-type', root),
            qs('#vinted-sale-price', root),
            qs('#vinted-item-cost', root),
            qs('#vinted-shipping-charge', root),
            qs('#vinted-shipping-cost', root)
        ];

        var results = qs('#vinted-results', root);
        var resVinted = qs('#res-vinted', root);
        var resVat = qs('#res-vat', root);
        var vatRow = qs('#vat-row', root);
        var resShipProfit = qs('#res-shipprofit', root);
        var resTotal = qs('#res-total', root);
        var resEarnings = qs('#res-earnings', root);
        var resProfit = qs('#res-profit', root);
        var resMargin = qs('#res-margin', root);

        function setDisabledState(disabled){
            inputs.forEach(function(i){ if(i){ i.disabled = disabled; } });
            if(disabled){ root.classList.add('vinted-disabled'); results.style.display = 'none'; }
            else { root.classList.remove('vinted-disabled'); results.style.display = 'block'; }
        }

        // restore email state
        var savedEmail = localStorage.getItem('vinted_email') || '';
        var confirmed = localStorage.getItem('vinted_email_confirmed') === '1';
        if(savedEmail){ email.value = savedEmail; }
        if(confirmed && savedEmail){ confirmBtn.textContent = '✔ Email Confirmed'; confirmBtn.disabled = true; setDisabledState(false); }
        else { setDisabledState(true); }

        confirmBtn.addEventListener('click', function(){
            var val = email.value.trim();
            if(!val || !/\S+@\S+\.\S+/.test(val)){
                alert('Please enter a valid email to continue');
                return;
            }
            confirmBtn.textContent = '✔ Email Confirmed';
            confirmBtn.disabled = true;
            localStorage.setItem('vinted_email', val);
            localStorage.setItem('vinted_email_confirmed', '1');
            setDisabledState(false);
            calculate();
        });

        clearBtn.addEventListener('click', function(){
            email.value = '';
            confirmBtn.textContent = 'Confirm Email';
            confirmBtn.disabled = false;
            localStorage.removeItem('vinted_email');
            localStorage.removeItem('vinted_email_confirmed');
            inputs.forEach(function(i){ if(i){ if(i.type === 'checkbox') i.checked = false; else i.value = ''; } });
            setDisabledState(true);
            [resVinted,resVat,resShipProfit,resTotal,resEarnings,resProfit,resMargin].forEach(function(el){ el.textContent='-'; el.classList.remove('positive','negative'); });
        });

        inputs.forEach(function(i){ if(!i) return; i.addEventListener('input', calculate); i.addEventListener('change', calculate); });

        function formatCurrency(val, symbol){
            if(isNaN(val)) return '-';
            var fixed = Number(val).toFixed(2);
            return symbol + fixed;
        }

        function calculate(){
            var region = (qs('#vinted-region', root).value || 'United States');
            var sellerType = (qs('#vinted-seller-type', root).value || 'Private Seller');
            var sale = parseFloat(qs('#vinted-sale-price', root).value) || 0;
            var itemCost = parseFloat(qs('#vinted-item-cost', root).value) || 0;
            var shippingCharge = parseFloat(qs('#vinted-shipping-charge', root).value) || 0;
            var shippingCost = parseFloat(qs('#vinted-shipping-cost', root).value) || 0;

            var rateObj = rates[region] || rates['United States'];
            var currency = (rateObj && rateObj.currency) ? rateObj.currency : '$';

            var sellerKey = (sellerType.toLowerCase().indexOf('pro') !== -1) ? 'pro' : 'private';
            var vintedRate = (rateObj && rateObj.vinted && typeof rateObj.vinted[sellerKey] !== 'undefined') ? parseFloat(rateObj.vinted[sellerKey]) : 0;
            var vatApplicable = (rateObj && rateObj.vat_applicable) ? true : false;
            var vatRate = (rateObj && rateObj.vat_rate) ? parseFloat(rateObj.vat_rate) : 0.2;

            // Vinted fee applies to sale price only
            var vintedFee = Number((sale * vintedRate).toFixed(2));

            var vatOnFee = 0;
            if(vatApplicable && sellerKey === 'pro' && vintedFee > 0){
                vatOnFee = Number((vintedFee * vatRate).toFixed(2));
                vatRow.style.display = 'flex';
            } else {
                vatOnFee = 0;
                vatRow.style.display = 'none';
            }

            // Shipping profit = shippingCharge - shippingCost
            var shipProfit = Number((shippingCharge - shippingCost).toFixed(2));

            // Total fees = vintedFee + vatOnFee
            var totalFees = Number((vintedFee + vatOnFee).toFixed(2));

            // Earnings = sale price - totalFees + shippingProfit
            var earnings = Number((sale - totalFees + shipProfit).toFixed(2));

            // Profit = earnings - itemCost
            var profit = Number((earnings - itemCost).toFixed(2));

            var margin = 0;
            if(earnings !== 0){ margin = Number(((profit / earnings) * 100).toFixed(1)); }

            resVinted.textContent = formatCurrency(vintedFee, currency);
            resVat.textContent = formatCurrency(vatOnFee, currency);
            resShipProfit.textContent = formatCurrency(shipProfit, currency);
            resTotal.textContent = formatCurrency(totalFees, currency);
            resEarnings.textContent = formatCurrency(earnings, currency);
            resProfit.textContent = formatCurrency(profit, currency);
            resMargin.textContent = margin + '%';

            [resEarnings,resProfit].forEach(function(el){ el.classList.remove('positive','negative'); var num = parseFloat(el.textContent.replace(/[^0-9.-]+/g,'')); if(!isNaN(num) && num >= 0) el.classList.add('positive'); else el.classList.add('negative'); });
        }

    });
})();